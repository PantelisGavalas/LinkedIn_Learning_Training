import os

class Config(object):
    SECRET_KEY = os.environ.get('SECRET_KEY') or b'E\xe2\xecm\xee\xfa\xf9-\x80\xc7\xc6j5"\x82%'

    MONGODB_SETTINGS = { 'db' : 'UTA_Enrollment' }


    