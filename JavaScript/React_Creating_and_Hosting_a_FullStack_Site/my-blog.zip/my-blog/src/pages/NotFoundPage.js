const NotFoundPage = () => {
    return (
        <>
            <h1>Page Not Found</h1>
            <p>The link you followed to get here must be broken...</p>
        </>
    );
};

export default NotFoundPage;
