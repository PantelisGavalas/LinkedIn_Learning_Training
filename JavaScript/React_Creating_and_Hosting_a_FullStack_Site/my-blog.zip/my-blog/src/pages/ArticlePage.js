import { useParams, useLoaderData } from "react-router-dom";
import articles from "../article-content";

const ArticlePage = () => {
    // We use the hook to get the URL Parameter
    const { name } = useParams();
    const { upvotes, comments } = useLoaderData();

    // We use the name (article's unique ID) to find the corresponding article in our article-content
    const article = articles.find((article) => article.name === name);

    // We return the article we got from the articleID URL Parameter
    return (
        // we wrap everything we return in a React Fragment
        // key --> makes it easy for React to rerender the list
        <>
            <h1>{article.title}</h1>
            {<p>This article has {upvotes} upvotes!</p>}
            {article.content.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
            ))}
        </>
    );
};

export default ArticlePage;
