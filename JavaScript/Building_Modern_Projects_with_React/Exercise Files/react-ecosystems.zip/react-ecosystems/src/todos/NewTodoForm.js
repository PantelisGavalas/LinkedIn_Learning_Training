import React, { useState } from "react";
import { connect } from "react-redux";
import { addTodoRequest } from "./thunks";
import { getTodos } from "./selectors";
import styled from "styled-components";
// We don't need this anymore since we have the styled-components
//import "./NewTodoForm.css";

/*
 ** Our styled-components to replace the CSS Module
 */
const FormContainer = styled.div`
    border-radius: 8px;
    padding: 16px;
    text-align: center;
    box-shadow: 0 4px 8px grey;
`;
const NewTodoInput = styled.input`
    font-size: 16px;
    padding: 8px;
    border: none;
    border-bottom: 2px solid #ddd;
    border-radius: 8px;
    width: 70%;
    outline: none;
    box-shadow: 0 2px 4px #ddd;
`;
const NewTodoButton = styled.button`
    font-size: 16px;
    font-weight: bold;
    padding: 8px;
    border: none;
    border-radius: 8px;
    outline: none;
    box-shadow: 0 2px 4px lightseagreen;
    cursor: pointer;
    margin-left: 8px;
    width: 20%;
    background-color: lightseagreen;
`;

/*
 ** We have a NewTodForm component.
 ** For this component, we create a state variable using useState
 ** to capture our input from the user.
 ** The component returns an input field as well as a button for
 ** the user to add new To-Do items.
 */
const NewTodoForm = ({ todos, onCreatePressed }) => {
    const [inputValue, setInputValue] = useState("");

    return (
        // replaced the div with the styled-component.
        // same for the other ones we had
        //<div className="new-todo-form">
        <FormContainer>
            <NewTodoInput
                //className="new-todo-input"    // no need we have styled-component
                type="text"
                placeholder="Type your new To-Do here..."
                value={inputValue}
                onChange={(event) => {
                    setInputValue(event.target.value);
                }}
                // Added functionality (extra from tutorial) for Enter key on input
                onKeyDown={(e) => {
                    if (e.key === "Enter") {
                        // prevent user from adding duplicate to-do text.
                        // some() returns true if any array item passes the test condition.
                        const isDuplicateText = todos.some(
                            (todo) => todo.text === inputValue
                        );
                        if (!isDuplicateText && inputValue != "") {
                            // when form button clicked we call
                            // action to add the new to-do
                            onCreatePressed(inputValue);
                            setInputValue(""); // initialize form input after button press
                        }
                    }
                }}
            />
            <NewTodoButton
                onClick={() => {
                    // prevent user from adding duplicate to-do text.
                    // some() returns true if any array item passes the test condition.
                    const isDuplicateText = todos.some(
                        (todo) => todo.text === inputValue
                    );
                    // extra check from tutorial for empty todo entry
                    if (!isDuplicateText && inputValue != "") {
                        // when form button clicked we call
                        // action to add the new to-do
                        onCreatePressed(inputValue);
                        setInputValue(""); // initialize form input after button press
                    }
                }}
                //className="new-todo-button"   // no need we have styled-component
            >
                Create To-Do
            </NewTodoButton>
        </FormContainer>
        //</div>  // replaced by above styled-component
    );
};

const mapStateToProps = (state) => ({
    todos: getTodos(state),
});

const mapDispatchToProps = (dispatch) => ({
    onCreatePressed: (text) => dispatch(addTodoRequest(text)),
});

export default connect(mapStateToProps, mapDispatchToProps)(NewTodoForm);
