import React from "react";
import styled from "styled-components";
// We don't need this anymore since we have the styled-components
//import "./TodoListItem.css";

/*
 ** Our styled-components to replace the CSS Module
 */
const TodoItemContainer = styled.div`
    background: #fff;
    border-radius: 8px;
    margin-top: 8px;
    padding: 16px;
    position: relative;
    box-shadow: 0 4px 8px grey;
`;
// This is an extending styled-component inheriting from our TodoItemContainer.
// It adds some styling for urgency to older than 5 days todos (1 day = 8640000 ms)
// We will use it only on incomplete todos.
// The function getBorderStyleForDate is used in our styled-component and
// is also used to test the styled-component.
export const getBorderStyleForDate = (startingDate, currentDate) =>
    startingDate > new Date(currentDate - 8640000 * 5)
        ? "none"
        : "4px solid red";
const TodoItemContainerWithWarning = styled(TodoItemContainer)`
    border-bottom: ${(props) =>
        getBorderStyleForDate(new Date(props.createdAt), Date.now())};
`;
// Also an extending styled-component inheriting from our TodoItemContainer.
// It adds some styling of completeness.
// We will use it only in our completed todos.
const TodoItemContainerCompleted = styled(TodoItemContainer)`
    background-color: #90ee90;
`;
const ButtonsContainer = styled.div`
    position: absolute;
    right: 12px;
    bottom: 12px;
`;
const Button = styled.button`
    font-size: 16px;
    font-weight: bold;
    padding: 8px;
    border: none;
    border-radius: 8px;
    outline: none;
    cursor: pointer;
    display: inline-block;
`;
// Below two are extending our Button styled-component
const CompletedButton = styled(Button)`
    background-color: #11b159;
    box-shadow: 0 2px 4px #11b159;
`;
const RemoveButton = styled(Button)`
    background-color: #ee2222;
    box-shadow: 0 2px 4px #ee2222;
    margin-left: 8px;
`;

/*
 ** We have a TodoListItem component that takes a
 ** todo prop as a property.
 ** For this todo, it returns its name along with two buttons:
 ** one for marking the task as complete and one for removing it.
 */
const TodoListItem = ({ todo, onRemovePressed, onCompletedPressed }) => {
    // Add check here to handle null or undefined todo
    if (!todo || !todo.text) {
        return <div>Invalid todo.</div>;
    }

    //Choose between container based on completeness of todo
    const Container = todo.isCompleted
        ? TodoItemContainerCompleted
        : TodoItemContainerWithWarning;

    return (
        // replaced the div with the styled-component.
        // same for the other ones we had
        //<div className="todo-item-container">
        <Container createdAt={todo.createdAt}>
            <h3>{todo.text}</h3>
            <p>
                Created at:&nbsp;
                {new Date(todo.createdAt).toLocaleDateString()}
            </p>
            <ButtonsContainer>
                {todo.isCompleted ? null : ( // if todo is completed don't show the "Mark As Completed" button
                    <CompletedButton
                        //className="completed-button"  // no need we have styled-component
                        onClick={() => onCompletedPressed(todo.id)}
                    >
                        Mark As Completed
                    </CompletedButton>
                )}
                <RemoveButton
                    //className="remove-button" // no need we have styled-component
                    onClick={() => onRemovePressed(todo.id)}
                >
                    Remove
                </RemoveButton>
            </ButtonsContainer>
        </Container>
        //</div>    // replaced by above styled-component
    );
};

export default TodoListItem;
