// We load the actions we will use in our thunks
import {
    loadTodosInProgress,
    loadTodosSuccess,
    loadTodosFailure,
    createTodo,
    removeTodo,
    markTodoAsCompleted,
} from "./actions";

/*
 ** This thunk is for loading data (todos) from the server.
 ** It is an async function (operation) and we take two arguments:
 ** --> dispatched is used to call other actions.
 ** --> getState is used to get the current state of the Redux Store.
 ** The process is to:
 ** - TRY to load data and call success with the fetched data once we get them
 ** - CATCH any error to call failure (and possibly alert the error).
 */
export const loadTodos = () => async (dispatch, getState) => {
    try {
        dispatch(loadTodosInProgress());
        const responce = await fetch("http://localhost:8080/todos");
        const todos = await responce.json();
        //console.log(todos); // DEBUG CONSOLE LOG
        dispatch(loadTodosSuccess(todos));
    } catch (e) {
        dispatch(loadTodosFailure());
        dispatch(displayAlert(e));
    }
};

/*
 ** Below thunk is used to be dispatched by NewTodoForm
 ** component to kick off the CREATE_TODO action.
 */
export const addTodoRequest = (text) => async (dispatch) => {
    try {
        const body = JSON.stringify({ text });
        //console.log("Body of new todo for POST request", body);   // DEBUG CONSOLE LOG
        // options for the fetch POST request
        const opts = {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body,
        };
        // this will be the new todo created on the server
        const responce = await fetch("http://localhost:8080/todos", opts);
        //console.log("Responce from server:", responce);   // DEBUG CONSOLE LOG
        const todo = await responce.json();
        //console.log("New todo from server:", todo); // DEBUG CONSOLE LOG
        dispatch(createTodo(todo));
    } catch (e) {
        console.error("Error adding todo:", e);
        dispatch(displayAlert(e));
    }
};

/*
 ** Below thunk is used to be dispatched to
 ** kick off the REMOVE_TODO action.
 */
export const removeTodoRequest = (id) => async (dispatch) => {
    try {
        // options for the delete request
        const opts = {
            method: "DELETE",
        };
        // this will be the deleted todo from the server
        const responce = await fetch(`http://localhost:8080/todos/${id}`, opts);
        //console.log("Responce from server:", responce); // DEBUG CONSOLE LOG
        const removedTodo = await responce.json();
        //console.log("Removed Todo from the server:", removedTodo); // DEBUG CONSOLE LOG
        dispatch(removeTodo(removedTodo));
    } catch (e) {
        console.error("Error removing todo:", e);
        dispatch(displayAlert(e));
    }
};

/*
 ** Below thunk is used to be dispatched to
 ** kick off the MARK_TODO_AS_COMPLETED action.
 */
export const markTodoAsCompletedRequest = (id) => async (dispatch) => {
    try {
        // options for the fetch POST request
        const opts = {
            method: "POST",
        };
        const responce = await fetch(
            `http://localhost:8080/todos/${id}/completed`,
            opts
        );
        //console.log("Responce from server:", responce); // DEBUG CONSOLE LOG
        const updatedTodo = await responce.json();
        //console.log("Updated Todo from the server:", updatedTodo); // DEBUG CONSOLE LOG
        dispatch(markTodoAsCompleted(updatedTodo));
    } catch (e) {
        console.error("Error updating todo:", e);
        dispatch(displayAlert(e));
    }
};

// This thunk is used to alert error message to the user.
export const displayAlert = (text) => () => {
    alert(text);
};
