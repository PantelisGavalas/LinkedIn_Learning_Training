import React, { useEffect } from "react";
import { connect } from "react-redux";
import styled from "styled-components";
import TodoListItem from "./TodoListItem";
import NewTodoForm from "./NewTodoForm";
import {
    loadTodos,
    markTodoAsCompletedRequest,
    removeTodoRequest,
} from "./thunks";
import {
    getTodosLoading,
    getCompletedTodos,
    getIncompleteTodos,
} from "./selectors";
// We don't need this anymore since we have the styled-components
// import "./TodoList.css";

/*
 ** Our styled-components to replace the CSS Module
 */
const ListWrapper = styled.div`
    max-width: 700px;
    margin: auto;
`;

/*
 ** We have a TodoList component that takes a
 ** todos prop as a property.
 ** We map through all todos and for each todo
 ** we return a TodoListItem.
 */
const TodoList = ({
    completedTodos,
    incompleteTodos,
    isLoading,
    onRemovePressed,
    onCompletedPressed,
    startLoadingTodos,
}) => {
    // We have this to fetch the data from the server (side effect)
    // to make use of our loading thunk function, actions and reducer.
    useEffect(() => {
        startLoadingTodos();
    }, []);

    // We have this for our Loading used for the Thunk Async loading
    const loadingMessage = <div>Loading To-Dos...</div>;

    const content = (
        // The below is replaced by the styled-component
        //<div className="list-wrapper">
        <ListWrapper>
            <NewTodoForm />
            <h3>Incomplete:</h3>
            {incompleteTodos.map((todo) => (
                <TodoListItem
                    todo={todo}
                    onRemovePressed={onRemovePressed}
                    onCompletedPressed={onCompletedPressed}
                />
            ))}
            <h3>Completed:</h3>
            {completedTodos.map((todo) => (
                <TodoListItem
                    todo={todo}
                    onRemovePressed={onRemovePressed}
                    onCompletedPressed={onCompletedPressed}
                />
            ))}
        </ListWrapper>
        //</div>    // replaced by the styled-component
    );

    return isLoading ? loadingMessage : content;
};

// We are creating Selectors for the mapStateToProps function
const mapStateToProps = (state) => ({
    completedTodos: getCompletedTodos(state),
    incompleteTodos: getIncompleteTodos(state),
    isLoading: getTodosLoading(state),
});

const mapDispatchToProps = (dispatch) => ({
    onRemovePressed: (id) => dispatch(removeTodoRequest(id)),
    onCompletedPressed: (id) => dispatch(markTodoAsCompletedRequest(id)),
    startLoadingTodos: () => dispatch(loadTodos()),
});

export default connect(mapStateToProps, mapDispatchToProps)(TodoList);
