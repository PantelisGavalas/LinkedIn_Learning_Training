import { createSelector } from "reselect";

// Selectors to get todos and their loading state
export const getTodos = (state) => state.todos.data;
export const getTodosLoading = (state) => state.todos.isLoading;

// Selector to get all the incomplete todos using Reselect
export const getIncompleteTodos = createSelector(getTodos, (todos) =>
    todos.filter((todo) => !todo.isCompleted)
);

// Selector to get all the completed todos using Reselect
export const getCompletedTodos = createSelector(getTodos, (todos) =>
    todos.filter((todo) => todo.isCompleted)
);
