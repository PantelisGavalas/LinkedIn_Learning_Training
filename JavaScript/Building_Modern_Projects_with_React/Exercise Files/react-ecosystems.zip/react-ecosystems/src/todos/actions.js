export const CREATE_TODO = "CREATE_TODO";
/*
 ** A function that creates our action object for us.
 ** We call it passing info for the payload as parameter.
 ** These functions are called action creators.
 */
export const createTodo = (todo) => ({
    type: CREATE_TODO,
    payload: { todo },
});

export const REMOVE_TODO = "REMOVE_TODO";
export const removeTodo = (todo) => ({
    type: REMOVE_TODO,
    payload: { todo },
});

export const MARK_TODO_AS_COMPLETED = "MARK_TODO_AS_COMPLETED";
export const markTodoAsCompleted = (todo) => ({
    type: MARK_TODO_AS_COMPLETED,
    payload: { todo },
});

/*
 ** Below three actions are to be used in the loadTodos thunk function.
 ** They are for the logic process of fetching data from the server.
 */
export const LOAD_TODOS_IN_PROGRESS = "LOAD_TODOS_IN_PROGRESS";
export const loadTodosInProgress = () => ({
    type: LOAD_TODOS_IN_PROGRESS,
});

export const LOAD_TODOS_SUCCESS = "LOAD_TODOS_SUCCESS";
export const loadTodosSuccess = (todos) => ({
    type: LOAD_TODOS_SUCCESS,
    payload: { todos },
});

export const LOAD_TODOS_FAILURE = "LOAD_TODOS_FAILURE";
export const loadTodosFailure = () => ({
    type: LOAD_TODOS_FAILURE,
});
