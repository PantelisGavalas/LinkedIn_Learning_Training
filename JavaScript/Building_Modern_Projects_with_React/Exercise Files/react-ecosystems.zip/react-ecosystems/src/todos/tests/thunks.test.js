import { expect } from "chai";
import sinon from "sinon";
import "node-fetch";
import fetchMock from "fetch-mock";
import { loadTodos } from "../thunks";

/*
 ** We define our test here.
 ** We want to test the actions and server fetch requests also.
 */
describe("The loadTodos thunk", () => {
    it("Dispatches the correct actions in the success scenario", async () => {
        // How we create a fake function that keeps track of which arguments it was called with.
        const fakeDispatch = sinon.spy();

        // Our fake fetch here:
        // When our thunk makes the request it just gets back the fakeTodos (fake responce) instead of sending an actual request.
        const fakeTodos = [{ text: "1" }, { text: "2" }];
        fetchMock.get("http://localhost:8080/todos", fakeTodos);

        // Expected actions our fake dispatch function gets called with.
        const expectedFirstAction = { type: "LOAD_TODOS_IN_PROGRESS" };
        const expectedSecondAction = {
            type: "LOAD_TODOS_SUCCESS",
            payload: {
                todos: fakeTodos,
            },
        };

        // Then, we call our thunk with the fake dispatch function.
        await loadTodos()(fakeDispatch);

        // We write what we expect to happen --> expected actions "dispatched" in correct order.
        expect(fakeDispatch.getCall(0).args[0]).to.deep.equal(
            expectedFirstAction
        );
        expect(fakeDispatch.getCall(1).args[0]).to.deep.equal(
            expectedSecondAction
        );

        // We finally restore our fetch to its original state.
        fetchMock.reset();
    });
});
