import { expect } from "chai";
import { getCompletedTodos } from "../selectors";

/*
 ** We define our test here.
 ** - We make fake data to pass to our createSelector selector's last function.
 ** - We define the expected result from our selector and the actual result from
 ** calling our selector.
 ** - We compare the actual result from our selector with the expected result.
 */
describe("The getCompletedTodos selector", () => {
    it("Returns only completed todos", () => {
        // Fake data for our selector
        const fakeTodos = [
            {
                text: "Say hello",
                isCompleted: true,
            },
            {
                text: "Say goodbye",
                isCompleted: false,
            },
            {
                text: "Climb Mount Everest",
                isCompleted: false,
            },
        ];

        // Expected results from selector.
        const expected = [
            {
                text: "Say hello",
                isCompleted: true,
            },
        ];
        // Actual results from our selector
        // .resultFunc references the last function declared as argument in our createSelector selector.
        // That's where the logic for transforiming data was defined (what we want to test).
        const actual = getCompletedTodos.resultFunc(fakeTodos);

        // Comparison of the expected and actual results.
        expect(actual).to.deep.equal(expected);
    });
});
