// We can use this to make assertions
import { expect } from "chai";
import { todos } from "../reducers";

/*
 ** We define our test here (the way Mocha organizes the tests).
 ** - We make a fake original state and a fake action (with a type and a payload)
 ** to pass to our reducer under test.
 ** - We make a constant to hold the expected result from our reducer
 ** and a constant to hold the actual result from calling our reducer.
 ** - We compare the actual result from our reducer with the expected result.
 */
describe("The todos reducer", () => {
    it("Adds a new todo when CREATE_TODO action is receiver", () => {
        const fakeTodo = { text: "Hello", isCompleted: false };
        const fakeAction = {
            type: "CREATE_TODO",
            payload: {
                todo: fakeTodo,
            },
        };
        const originalState = { isLoading: false, data: [] };

        const expected = {
            isLoading: false,
            data: [fakeTodo],
        };
        const actual = todos(originalState, fakeAction);

        expect(actual).to.deep.equal(expected);
    });
});
