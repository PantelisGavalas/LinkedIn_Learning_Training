import {
    CREATE_TODO,
    REMOVE_TODO,
    MARK_TODO_AS_COMPLETED,
    LOAD_TODOS_IN_PROGRESS,
    LOAD_TODOS_SUCCESS,
    LOAD_TODOS_FAILURE,
} from "./actions";

/*
 ** We combine our two reducers that we had for the todos data and the loading of the todos data into one reducer.
 **     state.todos: {
 **         isLoading: true or false,
 **         data: [...actual todos...],
 **     }

 ** We have an initialState to initialize our todos state. We then apply appropriate logic to each of our cases.
 ** The cases for loading data are shared for our todos data and our todos loading.
 ** So we combine their logic inside the one reducer.
 */
const initialState = {
    isLoading: false,
    data: [],
};
export const todos = (state = initialState, action) => {
    const { type, payload } = action;

    switch (type) {
        /*
         ** We create a new todo item based on the
         ** payload of the action and return our state
         ** (current todos) concatenated with the new todo.
         */
        case CREATE_TODO: {
            const { todo } = payload;
            // IMPORTANT NOT TO MUTATE THE STATE IN ANY WAY!
            // Spread operator to return the state as it was and
            // The concat method, that doesn't mutate it, to add the new todo.
            return {
                ...state,
                data: state.data.concat(todo),
            };
        }
        case REMOVE_TODO: {
            const { todo: todoToRemove } = payload;
            // The filter method will filter all todos
            // based on our criteria in its arrow function.
            return {
                ...state,
                data: state.data.filter((todo) => todo.id !== todoToRemove.id),
            };
        }
        case MARK_TODO_AS_COMPLETED: {
            const { todo: updatedTodo } = payload;
            /*
             ** Below implementation markes a todo as complete
             ** and moves it to bottom of the list or top of the list
             ** in the two returns respectively.
             */
            // we filter out the updated todo and
            // concat it with the rest of the todos
            updatedTodo.isCompleted = true;
            // - completed on bottom
            // return {
            //     ...state,
            //     data: state.data
            //         .filter((todo) => todo.id !== updatedTodo.id)
            //         .concat(updatedTodo),
            // };
            // - completed on top
            return {
                ...state,
                data: [updatedTodo].concat(
                    state.data.filter((todo) => todo.id !== updatedTodo.id)
                ),
            };

            /*
             ** Below implementation marks a todo as complete
             ** and keeps it in the same place as it was.
             */
            // return {
            //     ...state,
            //     data: state.data.map((todo) => {
            //         if (todo.id === updatedTodo.id) {
            //             updatedTodo.isCompleted = true;
            //             return updatedTodo;
            //         }
            //         return todo;
            //     }),
            // };
        }
        /*
         ** Below three cases are for loading the fetched data from
         ** our server (fetched in thunk function).
         */
        case LOAD_TODOS_SUCCESS: {
            const { todos } = payload;
            return {
                ...state,
                isLoading: false,
                data: todos,
            };
        }
        case LOAD_TODOS_IN_PROGRESS:
            return {
                ...state,
                isLoading: true,
            };
        case LOAD_TODOS_FAILURE:
            return {
                ...state,
                isLoading: false,
            };
        /*
         ** If the action triggered doesn't concern us we'll reach
         ** the default case, where we just don't make any change
         ** and return the state as it is.
         */
        default:
            return state;
    }
};
