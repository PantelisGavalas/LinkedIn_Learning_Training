import React from "react";
import ReactDOM from "react-dom";
// below two used for "Persisting the Redux Store"
import { persistStore } from "redux-persist";
import { PersistGate } from "redux-persist/lib/integration/react";
import { Provider } from "react-redux";
import { configureStore } from "./store.js";
import App from "./App.js";

const store = configureStore();
// used from video "Persisting the Redux Store"
const persistor = persistStore(store);

ReactDOM.render(
    <Provider store={store}>
        <PersistGate //used for "Persisting the Redux Store"
            loading={<div>Loading...</div>} // what is seen while loading our data
            persistor={persistor}
        >
            <App />
        </PersistGate>
    </Provider>,
    document.getElementById("root")
);
