import React from "react";
import styled from "styled-components";
import TodoList from "./todos/TodoList";
// We don't need this anymore since we have the styled-components
//import "./App.css";

/*
 ** Our styled-components to replace the CSS Module
 */
const AppContainer = styled.div`
    margin: 1rem;
    font-family: Arial, Helvetica, sans-serif;
    color: #222222;
    width: 100vw;
    height: 100vh;
`;

const App = () => (
    // The below is replaced by the styled-component
    //<div className="App">
    <AppContainer>
        <TodoList />
    </AppContainer>
    //</div>  // replaced by the styled-component
);

export default App;
