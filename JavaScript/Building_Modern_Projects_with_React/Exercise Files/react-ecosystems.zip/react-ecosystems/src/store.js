// we import createStore through legacy because it is deprecated.
// configureStore from Redux Toolkit is an improved version of createStore that simplifies setup and helps avoid common bugs.
import {
    legacy_createStore as createStore,
    combineReducers,
    applyMiddleware,
} from "redux";
// bellow three added for "Persisting the Redux Store"
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import autoMergeLevel2 from "redux-persist/lib/stateReconciler/autoMergeLevel2";
import { thunk } from "redux-thunk";
import { composeWithDevTools } from "@redux-devtools/extension";
import { todos } from "./todos/reducers";

// our reducers object
const reducers = {
    todos,
};

// used for "Persisting the Redux Store"
const persistConfig = {
    key: "root",
    storage, // imported above (defaults to local web storage)
    // this tells Redux Persist how to reconcile the initial
    // and stored states of our application
    stateReconciler: autoMergeLevel2,
};

// puts our reducers in a form that we can pass
// to the createStore function
const rootReducer = combineReducers(reducers);
// used for "Persisting the Redux Store"
const persistedReducer = persistReducer(persistConfig, rootReducer);

export const configureStore = () =>
    createStore(persistedReducer, composeWithDevTools(applyMiddleware(thunk)));
