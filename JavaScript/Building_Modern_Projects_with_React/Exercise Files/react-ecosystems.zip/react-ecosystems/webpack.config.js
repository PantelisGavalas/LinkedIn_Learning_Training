const path = require("path");
const webpack = require("webpack");
const ReactRefreshWebpackPlugin = require("@pmmmwh/react-refresh-webpack-plugin");

//our export which contains a bunch of configuration data for webpack
module.exports = {
    entry: "./src/index.js", // entry point for webpack
    mode: "development",
    //now we specify the rules for how we want webpack to transform our code
    //webpack uses what is called "loaders" for this
    module: {
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /(node_modules)/,
                loader: "babel-loader",
                options: { presets: ["@babel/env"] },
            },
            {
                test: /\.css$/,
                use: ["style-loader", "css-loader"],
            },
        ],
    },
    resolve: {
        extensions: ["*", ".js", ".jsx"],
    },
    output: {
        path: path.resolve(__dirname, "dist/"),
        publicPath: "/dist/",
        filename: "bundle.js",
    },
    devServer: {
        static: path.join(__dirname, "public/"),
        port: 3000,
        devMiddleware: {
            publicPath: "http://localhost:3000/dist/",
        },
        hot: true,
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin(),
        new ReactRefreshWebpackPlugin(),
    ],
};
