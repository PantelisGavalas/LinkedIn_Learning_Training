package com.frankmoley.lil.sbet.clr.roomclr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomClrApplicationTests {

	@Test
	void contextLoads() {
	}

}
