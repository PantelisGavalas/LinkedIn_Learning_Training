package com.frankmoley.lil.sbet.landon.roomwebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoomWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
