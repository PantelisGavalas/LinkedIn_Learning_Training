package com.frankmoley.lil.sbet.bootingweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootingWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootingWebApplication.class, args);
	}

}
