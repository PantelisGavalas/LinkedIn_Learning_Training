package pantelisgavalas.lil.sbet.booting_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootingWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
